{
	"name" : "Capture the Flag",
	"scene" : "capturetheflag/capturetheflag.scene",
	"resources" : ["capturetheflag", "soldier2red", "soldier2green", "bullet"],
	"logic"  : "ctflogic.js"
}