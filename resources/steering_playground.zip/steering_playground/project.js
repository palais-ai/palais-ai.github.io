{
	"name" : "Steering Playground",
	"scene" : "scene/playground.scene",
	"resources" : ["scene", "soldier2red", "soldier2green"],
	"logic"  : "scenario.js"
}