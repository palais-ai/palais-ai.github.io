function onSetup() {
	var actor = Scene.instantiate("myCube", "Cube", new Vector3(0,0,0));
	actor.setScale(0.1)
}

function onTeardown() {
}

function update(deltaTime) {
}