{
    "name" : "my_scene",
    "scene" : "",
    "resources" : ["../cube_model"],
    "logic"  : "main.js"
}